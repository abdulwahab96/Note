package com.abdulhadi.abdulwahab.notes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import static com.abdulhadi.abdulwahab.notes.MainActivity.numbers;

public class type_note extends AppCompatActivity {

    EditText et_note;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type_note);

        et_note = (EditText) findViewById(R.id.et_edit_note);

        et_note.setText(getIntent().getStringExtra("note"));
    }

    @Override
    public void onBackPressed() {
        String note = et_note.getText().toString();
        int index = getIntent().getIntExtra("pos", numbers.size() - 1);
        if (note.trim().length() > 0)
            numbers.set(index, note);
        else
            numbers.remove(index);
        super.onBackPressed();
    }
}
