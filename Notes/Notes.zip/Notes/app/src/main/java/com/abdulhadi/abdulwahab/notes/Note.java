package com.abdulhadi.abdulwahab.notes;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Note {
    @PrimaryKey
    public int uid;

    @ColumnInfo(name = "note")
    public String note;

    @ColumnInfo(name = "last_edit")
    public String lastEdit;
}
